#!/bin/sh

echo "正在删除其他分辨率(720P和1080P)资源，请稍等......" 

cd ..
cd ..
cd ..
cd res/drawable-xhdpi-v4

echo "正在删除720P分辨率资源"

echo "正在删除[framework]相关资源"
rm category_tool.*
rm icon_download_cover.*
rm operate_more_app_icon_in_other_theme.*
rm operate_more_app_icon_in_sysytem_theme.*
rm operate_virtual_item_default_icon.*


echo "正在删除[一键换壁纸]相关资源"
rm default_change_wallpaper_bg.*
rm default_change_wallpaper_finger.*
rm ic_launcher.*
 

echo "正在删除[launcher3的壁纸选择]相关资源"
rm ic_actionbar_accept.*
rm ic_images.*
rm tile_picker_focused.9.*
rm tile_picker_pressed.9.*
rm tile_picker_selected.9.*
rm tile_shadow_bottom.9.*
rm tile_shadow_top.9.*


echo "正在删除[launcher]相关资源"
rm app_menu_button.*
rm app_menu_checkbox_checked.*
rm app_menu_checkbox_normal.*
rm app_menu_navigation_back.*
rm application_infomation_icon_focus.*
rm application_infomation_icon_normal.*
rm bg_appwidget_error.9.*
rm cling.9.*
rm cling_arrow_down.*
rm cling_arrow_left.*
rm cling_arrow_right.*
rm cling_arrow_up.*
rm cling_button.9.*

rm cling_button_pressed.9.*
rm cool_ml_notify.*
rm default_config_beauty_center.*
rm default_config_category.*
rm default_config_launcher_setting.*
rm default_launcher_tips_dialog_logo.*
rm disclaimer_dialog_exit_normal.*
rm disclaimer_dialog_exit_pressed.*
rm download_notification_icon.*
rm focused_bg.9.*
rm hotseat_all_apps_button_icon_focus.*
rm hotseat_all_apps_button_icon_normal.*
rm ic_all_apps_bg_hand.*
 
rm ic_all_apps_bg_icon_1.*
rm ic_all_apps_bg_icon_2.*
rm ic_all_apps_bg_icon_3.*
rm ic_all_apps_bg_icon_4.*
rm ic_allapps.*
rm ic_allapps_pressed.*
rm ic_arrow_back_grey.*
rm ic_pageindicator_add.*
rm ic_pageindicator_camera_current.*
rm ic_pageindicator_camera_default.*
rm ic_pageindicator_current.*
rm ic_pageindicator_custom_content_current.*
rm ic_pageindicator_custom_content_default.*

rm ic_pageindicator_default.*
rm ic_pageindicator_home_current.*
rm ic_pageindicator_home_default.*
rm ic_pageindicator_music_current.*
rm ic_pageindicator_music_default.*
rm ic_search_grey.*
rm ic_wallpaper_chooser_uni3.*
rm icon_house_0.*
rm icon_house_1.*
rm icon_house_2.*
rm icon_house_3.*
rm icon_house_4.*
rm icon_house_5.*

rm icon_house_6.*
rm icon_house_7.*
rm icon_house_8.*
rm icon_house_9.*
rm icon_house_11.*
rm icon_house_default.*
rm icon_house_deskclock.*
rm icon_house_deskclock_center.*
rm icon_house_deskclock_hour.*
rm icon_house_deskclock_min.*
rm icon_house_deskclock_sec.*
rm icon_house_fri.*
rm icon_house_mon.*

rm icon_house_sat.*
rm icon_house_sun.*
rm icon_house_the.*
rm icon_house_tue.*
rm icon_house_wed.*
rm launcher_setting_app_icon_size.*
rm launcher_settings_checkbox_button_icon_selected.*
rm launcher_settings_checkbox_button_icon_unselected.*
rm launcher_settings_classification_icon.*
rm launcher_settings_desktopstyle_icon.*
rm launcher_settings_effect_icon.*
rm launcher_settings_home_icon.*
rm launcher_settings_icon.*

rm launcher_settings_l2r_back.*
rm launcher_settings_l2r_indicator.*
rm launcher_settings_r2l_back.*
rm launcher_settings_r2l_indicator.*
rm loading_img.*
rm market_icon_in_app_tab_host.*
rm native_adver_logo.*
rm native_adver_refresh.*
rm overscroll_glow_left.9.*
rm overscroll_glow_right.9.*
rm overview_panel_button_beauty_center_icon_focus.*
rm overview_panel_button_beauty_center_icon_normal.*
rm overview_panel_button_launcher_settings_icon_focus.*

rm overview_panel_button_launcher_settings_icon_normal.*
rm overview_panel_button_system_settings_icon_focus.*
rm overview_panel_button_system_settings_icon_normal.*
rm overview_panel_button_widgets_icon_focus.*
rm overview_panel_button_widgets_icon_normal.*
rm page_hover_left_holo.9.*
rm page_hover_right_holo.9.*
rm portal_container_holo.9.*
rm portal_ring_inner_nolip_holo.*
rm portal_ring_rest.*
rm quantum_panel_bitmap.9.*
rm quantum_panel_dark_bitmap.9.*
rm screenpanel.9.*

rm screenpanel_hover.9.*
rm search_bar_search_button_icon_fallback_focus.*
rm search_bar_search_button_icon_fallback_normal.*
rm search_bar_voice_button_icon_fallback.*
rm tab_selected_focused_holo.9.*
rm tab_selected_holo.9.*
rm tab_selected_pressed_focused_holo.9.*
rm tab_selected_pressed_holo.9.*
rm tab_unselected_focused_holo.9.*
rm tab_unselected_holo.9.*
rm tab_unselected_pressed_focused_holo.9.*
rm tab_unselected_pressed_holo.9.*
rm theme_default_browser.*

rm theme_default_calculator.*
rm theme_default_calendar.*
rm theme_default_callhistroy.*
rm theme_default_camera.*
rm theme_default_clock.*
rm theme_default_cocolocker.*
rm theme_default_contacts.*
rm theme_default_download.*
rm theme_default_email.*
rm theme_default_files.*
rm theme_default_fm.*
rm theme_default_folder_icon_bg.*
rm theme_default_gallery.*

rm theme_default_messaging.*
rm theme_default_music.*
rm theme_default_phone.*
rm theme_default_record.*
rm theme_default_search.*
rm theme_default_settings.*
rm theme_default_theme.*
rm theme_default_video.*
rm theme_default_wallpaper.*
rm theme_default_weather.*
rm trash_icon_when_remove_item_focus.*
rm trash_icon_when_remove_item_normal.*
rm trash_icon_when_uninstall_item_focus.*

rm trash_icon_when_uninstall_item_normal.*
rm uiupdate_actionbat_btn_checked.*
rm uiupdate_actionbat_btn_unchecked.*
rm uiupdate_launcher_settings_about_icon.*
rm uiupdate_launcher_update_icon.*
rm uiupdate_update_dialog_logo.*
rm uiupdate_update_logo.*
rm widget_resize_frame_holo.9.*
rm widget_resize_handle_bottom.*
rm widget_resize_handle_left.*
rm widget_resize_handle_right.*
rm widget_resize_handle_top.*
rm widget_tile.*

rm widget_time_am.*
rm widget_time_dian.*
rm widget_time_icon.*
rm widget_time_pm.*
rm widget_time_t0.*
rm widget_time_t1.*
rm widget_time_t2.*
rm widget_time_t3.*
rm widget_time_t4.*
rm widget_time_t5.*
rm widget_time_t6.*
rm widget_time_t7.*
rm widget_time_t8.*

rm widget_time_t9.*

cd ..
cd mipmap-xhdpi-v4

echo "正在删除[mipmap]相关资源"
rm ic_launcher_home.*
rm ic_wallpaper_chooser_launcher3.*

echo "720P分辨率资源删除完毕 "


cd ..
cd drawable-xxhdpi-v4

echo "正在删除1080P分辨率资源"

echo "正在删除[framework]相关资源"
rm category_tool.*
rm icon_download_cover.*
rm operate_more_app_icon_in_other_theme.*
rm operate_more_app_icon_in_sysytem_theme.*
rm operate_virtual_item_default_icon.*


echo "正在删除[一键换壁纸]相关资源"
rm default_change_wallpaper_bg.*
rm default_change_wallpaper_finger.*
rm ic_launcher.*


echo "正在删除[launcher3的壁纸选择]相关资源"
rm ic_actionbar_accept.*
rm ic_images.*
rm tile_picker_focused.9.*
rm tile_picker_pressed.9.*
rm tile_picker_selected.9.*
rm tile_shadow_bottom.9.*
rm tile_shadow_top.9.*


echo "正在删除[launcher]相关资源"
rm app_menu_button.*
rm app_menu_checkbox_checked.*
rm app_menu_checkbox_normal.*
rm app_menu_navigation_back.*
rm application_infomation_icon_focus.*
rm application_infomation_icon_normal.*
rm bg_appwidget_error.9.*
rm cling.9.*
rm cling_arrow_down.*
rm cling_arrow_left.*
rm cling_arrow_right.*
rm cling_arrow_up.*
rm cling_button.9.*
 
rm cling_button_pressed.9.*
rm cool_ml_notify.*
rm default_config_beauty_center.*
rm default_config_category.*
rm default_config_launcher_setting.*
rm default_launcher_tips_dialog_logo.*
rm disclaimer_dialog_exit_normal.*
rm disclaimer_dialog_exit_pressed.*
rm download_notification_icon.*
rm focused_bg.9.*
rm hotseat_all_apps_button_icon_focus.*
rm hotseat_all_apps_button_icon_normal.*
rm ic_all_apps_bg_hand.*

rm ic_all_apps_bg_icon_1.*
rm ic_all_apps_bg_icon_2.*
rm ic_all_apps_bg_icon_3.*
rm ic_all_apps_bg_icon_4.*
rm ic_allapps.*
rm ic_allapps_pressed.*
rm ic_arrow_back_grey.*
rm ic_pageindicator_add.*
rm ic_pageindicator_camera_current.*
rm ic_pageindicator_camera_default.*
rm ic_pageindicator_current.*
rm ic_pageindicator_custom_content_current.*
rm ic_pageindicator_custom_content_default.*

rm ic_pageindicator_default.*
rm ic_pageindicator_home_current.*
rm ic_pageindicator_home_default.*
rm ic_pageindicator_music_current.*
rm ic_pageindicator_music_default.*
rm ic_search_grey.*
rm ic_wallpaper_chooser_uni3.*
rm icon_house_0.*
rm icon_house_1.*
rm icon_house_2.*
rm icon_house_3.*
rm icon_house_4.*
rm icon_house_5.*

rm icon_house_6.*
rm icon_house_7.*
rm icon_house_8.*
rm icon_house_9.*
rm icon_house_11.*
rm icon_house_default.*
rm icon_house_deskclock.*
rm icon_house_deskclock_center.*
rm icon_house_deskclock_hour.*
rm icon_house_deskclock_min.*
rm icon_house_deskclock_sec.*
rm icon_house_fri.*
rm icon_house_mon.*

rm icon_house_sat.*
rm icon_house_sun.*
rm icon_house_the.*
rm icon_house_tue.*
rm icon_house_wed.*
rm launcher_setting_app_icon_size.*
rm launcher_settings_checkbox_button_icon_selected.*
rm launcher_settings_checkbox_button_icon_unselected.*
rm launcher_settings_classification_icon.*
rm launcher_settings_desktopstyle_icon.*
rm launcher_settings_effect_icon.*
rm launcher_settings_home_icon.*
rm launcher_settings_icon.*

rm launcher_settings_l2r_back.*
rm launcher_settings_l2r_indicator.*
rm launcher_settings_r2l_back.*
rm launcher_settings_r2l_indicator.*
rm loading_img.*
rm market_icon_in_app_tab_host.*
rm native_adver_logo.*
rm native_adver_refresh.*
rm overscroll_glow_left.9.*
rm overscroll_glow_right.9.*
rm overview_panel_button_beauty_center_icon_focus.*
rm overview_panel_button_beauty_center_icon_normal.*
rm overview_panel_button_launcher_settings_icon_focus.*

rm overview_panel_button_launcher_settings_icon_normal.*
rm overview_panel_button_system_settings_icon_focus.*
rm overview_panel_button_system_settings_icon_normal.*
rm overview_panel_button_widgets_icon_focus.*
rm overview_panel_button_widgets_icon_normal.*
rm page_hover_left_holo.9.*
rm page_hover_right_holo.9.*
rm portal_container_holo.9.*
rm portal_ring_inner_nolip_holo.*
rm portal_ring_rest.*
rm quantum_panel_bitmap.9.*
rm quantum_panel_dark_bitmap.9.*
rm screenpanel.9.*

rm screenpanel_hover.9.*
rm search_bar_search_button_icon_fallback_focus.*
rm search_bar_search_button_icon_fallback_normal.*
rm search_bar_voice_button_icon_fallback.*
rm tab_selected_focused_holo.9.*
rm tab_selected_holo.9.*
rm tab_selected_pressed_focused_holo.9.*
rm tab_selected_pressed_holo.9.*
rm tab_unselected_focused_holo.9.*
rm tab_unselected_holo.9.*
rm tab_unselected_pressed_focused_holo.9.*
rm tab_unselected_pressed_holo.9.*
rm theme_default_browser.*

rm theme_default_calculator.*
rm theme_default_calendar.*
rm theme_default_callhistroy.*
rm theme_default_camera.*
rm theme_default_clock.*
rm theme_default_cocolocker.*
rm theme_default_contacts.*
rm theme_default_download.*
rm theme_default_email.*
rm theme_default_files.*
rm theme_default_fm.*
rm theme_default_folder_icon_bg.*
rm theme_default_gallery.*

rm theme_default_messaging.*
rm theme_default_music.*
rm theme_default_phone.*
rm theme_default_record.*
rm theme_default_search.*
rm theme_default_settings.*
rm theme_default_theme.*
rm theme_default_video.*
rm theme_default_wallpaper.*
rm theme_default_weather.*
rm trash_icon_when_remove_item_focus.*
rm trash_icon_when_remove_item_normal.*
rm trash_icon_when_uninstall_item_focus.*

rm trash_icon_when_uninstall_item_normal.*
rm uiupdate_actionbat_btn_checked.*
rm uiupdate_actionbat_btn_unchecked.*
rm uiupdate_launcher_settings_about_icon.*
rm uiupdate_launcher_update_icon.*
rm uiupdate_update_dialog_logo.*
rm uiupdate_update_logo.*
rm widget_resize_frame_holo.9.*
rm widget_resize_handle_bottom.*
rm widget_resize_handle_left.*
rm widget_resize_handle_right.*
rm widget_resize_handle_top.*
rm widget_tile.*

rm widget_time_am.*
rm widget_time_dian.*
rm widget_time_icon.*
rm widget_time_pm.*
rm widget_time_t0.*
rm widget_time_t1.*
rm widget_time_t2.*
rm widget_time_t3.*
rm widget_time_t4.*
rm widget_time_t5.*
rm widget_time_t6.*
rm widget_time_t7.*
rm widget_time_t8.*

rm widget_time_t9.*

cd ..
cd mipmap-xxhdpi-v4

echo "正在删除[mipmap]相关资源"
rm ic_launcher_home.*
rm ic_wallpaper_chooser_launcher3.*

echo "1080P分辨率资源删除完毕"
echo "其他分辨率(720P和1080P)资源删除完毕" 

read -p "按任意键继续" var
